// uiEvents.js
export const UI_EVENTS = {
  OPEN_MANUAL_MODAL: 'ui:open-manual-modal',
  CLOSE_MANUAL_MODAL: 'ui:close-manual-modal',
}